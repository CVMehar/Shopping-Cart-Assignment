package com.deloitte.Loginassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
